package com.example.age;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText nameText,ageText,heratText;
    private Button button;
    private String name;
    private int age;int heartbit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameText=findViewById(R.id.editTextTextPersonName);
        ageText=findViewById(R.id.editTextTextPersonName2);
        heratText=findViewById(R.id.editTextTextPersonName3);
        button=findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData();
            }
        });
    }
    public void sendData()
    {
        name=nameText.getText().toString().trim();
        age=Integer.parseInt(ageText.getText().toString().trim());
        heartbit=Integer.parseInt(heratText.getText().toString());
        Intent i=new Intent(MainActivity.this,MainActivity2.class);
        i.putExtra(MainActivity2.NAME,name);
        i.putExtra(MainActivity2.AGE,age);
        i.putExtra(MainActivity2.HEART_BIT,heartbit);
        startActivity(i);
    }
}