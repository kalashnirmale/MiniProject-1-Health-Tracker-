package com.example.age;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    public static final String NAME ="NAME";
    public static final String AGE ="AGE";
    public static final String HEART_BIT="HEART_BIT";
    private TextView nameText,ageText,heartText;
    private String name;
    private int age;
    private int heartbit;
    private Button b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        nameText=findViewById(R.id.mName);
        ageText=findViewById(R.id.mAge);
        heartText=findViewById(R.id.mHeartbit);


        Intent i=getIntent();
        name=i.getStringExtra(NAME);
        age = i.getIntExtra(AGE,0);
        heartbit=i.getIntExtra(HEART_BIT,75);

        nameText.setText("Your Name is"+name);
        if(age>=51 && heartbit>= 80){
        ageText.setText("Your Age is  "+age);
        heartText.setText("Cureent heart rate"+heartbit+" Tachycardia (Abnormal Heart Bits)");
        }
        if(age<50 && heartbit<80)
        {
            ageText.setText("Your Age is"+age);
            heartText.setText("Cureent heart rate"+heartbit+" Case of Bradycardia ");
        }
        else
        {
            ageText.setText("Your Age is"+age);
            heartText.setText("Cureent heart rate"+heartbit);
        }
        b2=findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii=new Intent(MainActivity2.this,MainActivity3.class);
                startActivity(ii);
            }
        });
    }
}